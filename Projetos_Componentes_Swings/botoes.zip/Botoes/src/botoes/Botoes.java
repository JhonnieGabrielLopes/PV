/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package botoes;

/**
 *
 * @author igormelo
 */
public class Botoes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BotoesTela botoesTela = new BotoesTela();
        botoesTela.setVisible(true);
    }
    
}
